<?php

declare(strict_types = 1);

namespace core\rank;

use core\Elemental;
use pocketmine\utils\TextFormat;

class RankManager {

    /** @var Elemental */
    private $core;

    /** @var Rank[] */
    private $ranks = [];

    /**
     * RankManager constructor.
     *
     * @param Elemental $core
     *
     * @throws RankException
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
        $core->getServer()->getPluginManager()->registerEvents(new RankListener($core), $core);
        $this->init();
    }

    /**
     * @throws RankException
     */
    public function init(): void {
                $this->addRank(new Rank("Adventurer", TextFormat::RESET, TextFormat::RESET . "§2§lADVENTURER§r", Rank::ADVENTURER, // DEFAULT RANK
            "§f❆ §3{faction_rank}{faction}§r §2§lADVENTURER §r§8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §7{message}",
            "§3{faction_rank}{faction}§r §2§lADVENTURER §r§8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 5, 1, [
                "permission.starter",
                "permission.once"
            ]));
                $this->addRank(new Rank("Ivara", TextFormat::RESET, TextFormat::RESET . "§b§lIVARA§r", Rank::IVARA, // FREE RANK
            "§f❆ §3{faction_rank}{faction} §b§lIVARA§r §8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §3{message}",
            "§3{faction_rank}{faction} §b§lIVARA§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 7, 2,  [
                "permission.starter",
                "permission.avatar",
                "permission.once"
            ]));
                $this->addRank(new Rank("Midas", TextFormat::RESET, TextFormat::RESET . "§e§lMIDAS", Rank::MIDAS, // FREE RANK
            "§f❆ §3{faction_rank}{faction} §e§lMIDAS§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §e{message}",
            "§3{faction_rank}{faction} §e§lMIDAS§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 7, 2,  [
                "permission.starter",
                "permission.avatar",
                "permission.janus",
                "permission.once"
            ]));
        $this->addRank(new Rank("Aphrodite", TextFormat::RESET, TextFormat::RESET . "§a§lAPHRODITE§r", Rank::APHRODITE, // FREE RANK
            "§f❆ §3{faction_rank}{faction} §a§lAPHRODITE§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §2{message}",
            "§3{faction_rank}{faction} §a§lAPHRODITE§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 11, 4, [
                "permission.starter",
                "permission.avatar",
				"permission.janus",
				"permission.iris",
                "permission.midas",
                "permission.aphrodite",
                "permission.once"
            ]));
        $this->addRank(new Rank("Erebus", TextFormat::RESET, TextFormat::RESET . "§b§lE§3R§bE§3B§bU§3S§r", Rank::EREBUS, // FREE RANK
            "§f❆ §3{faction_rank}{faction} §b§lE§3R§bE§3B§bU§3S§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §b{message}",
            "§3{faction_rank}{faction} §b§lE§3R§bE§3B§bU§3S§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 13, 5, [
                "permission.starter",
                "permission.avatar",
				"permission.janus",
				"permission.iris",
                "permission.midas",
                "permission.aphrodite",
                "permission.erebus",
				"permission.tier1",
				"permission.tier2",
                "permission.once"
            ]));
        $this->addRank(new Rank("Phoenix", TextFormat::RESET, TextFormat::RESET . "§e§lP§6H§eO§6E§eN§6I§eX§r", Rank::PHOENIX,
            "§f❆ §3{faction_rank}{faction} §e§lP§6H§eO§6E§eN§6I§eX§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §e{message}",
            "§3{faction_rank}{faction} §e§lP§6H§eO§6E§eN§6I§eX§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 15, 6, [
                "permission.starter",
                "permission.avatar",
                "permission.janus",
                "permission.iris",
                "permission.midas",
                "permission.aphrodite",
                "permission.erebus",
                "permission.phoenix",
                "permission.tier1",
                "permission.tier2",
                "permission.once"
            ]));
        $this->addRank(new Rank("Arcane", TextFormat::RESET, TextFormat::RESET . "§d§lA§5R§dC§5A§dN§5E§r", Rank::ARCANE,
            "§3{faction_rank}{faction} §d§lA§5R§dC§5A§dN§5E§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §d{message}",
            "§3{faction_rank}{faction} §d§lA§5R§dC§5A§dN§5E§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 15, 8, [
                "permission.starter",
                "permission.avatar",
                "permission.janus",
                "permission.iris",
                "permission.midas",
                "permission.aphrodite",
                "permission.erebus",
                "permission.phoenix",
                "permission.arcane",
                "permission.tier1",
                "permission.tier2",
                "permission.once"
            ]));
        $this->addRank(new Rank("Eros", TextFormat::RESET, TextFormat::RESET . "§d§lEROS§r", Rank::EROS,
            "§3{faction_rank}{faction} §d§lEROS§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §d{message}",
            "§3{faction_rank}{faction} §d§lEROS§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 18, 10, [
                "permission.starter",
                "permission.tier1",
                "permission.avatar",
                "permission.janus",
                "permission.iris",
                "permission.midas",
                "permission.aphrodite",
                "permission.erebus",
                "permission.phoenix",
                "permission.arcane",
                "permission.eros",
                "permission.tier2",
                "permission.once"
            ]));
        $this->addRank(new Rank("Artisan", TextFormat::RESET, TextFormat::RESET . "§b§lA§fR§bT§fI§bS§fA§bN§r", Rank::ARTISAN,
            "§3{faction_rank}{faction} §b§lA§fR§bT§fI§bS§fA§bN§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §b{message}",
            "§3{faction_rank}{faction} §b§lA§fR§bT§fI§bS§fA§bN§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 25, 15, [
                "permission.starter",
                "permission.avatar",
                "permission.janus",
                "permission.iris",
                "permission.midas",
                "permission.aphrodite",
                "permission.erebus",
                "permission.phoenix",
                "permission.arcane",
                "permission.eros",
                "permission.tartarus",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.once",
                "permission.join.full"
            ]));
        $this->addRank(new Rank("Youtuber+", TextFormat::RESET, TextFormat::RESET . "§l§cYOU§fTUBER§r§f+", Rank::YOUTUBER_PLUS,
            "§3{faction_rank}{faction} §l§cYOU§fTUBER§r§f+ §r§8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §c{message}",
            "§3{faction_rank}{faction} §l§cYOU§fTUBER§r§f+ §r§8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 25, 15, [
                "permission.starter",
                "permission.avatar",
                "permission.janus",
                "permission.iris",
                "permission.midas",
                "permission.aphrodite",
                "permission.erebus",
                "permission.phoenix",
                "permission.arcane",
                "permission.eros",
                "permission.tartarus",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.once",
                "permission.join.full"
            ]));
        $this->addRank(new Rank("Trainee", TextFormat::RESET, TextFormat::RESET . "§l§bTRAINEE§r", Rank::TRAINEE,
            "§3{faction_rank}{faction} §l§bTRAINEE§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §b{message}",
            "§3{faction_rank}{faction} §l§bTrainee§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}", 20, 10, [
               "permission.starter",
                "permission.god",
                "permission.warlord",
                "permission.overlord",
                "permission.avatar",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.staff",
                "permission.join.full",
                "bansystem.command.kick",
                "bansystem.command.mutelist",
                "bansystem.command.tempmute",
                "permission.once"
            ]));
        $this->addRank(new Rank("Mod", TextFormat::RESET, TextFormat::RESET . "§l§cMOD§r", Rank::MODERATOR,
            "§3{faction_rank}{faction} §l§cMODERATOR§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}: §c{message}",
            "§3{faction_rank}{faction} §l§cModerator§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}", 25, 15, [
                "permission.starter",
                "permission.god",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.avatar",
                "permission.join.full",
                "permission.staff",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("Senior-Mod", TextFormat::RESET, TextFormat::RESET . "§l§cSENIOR MOD§r", Rank::SENIOR_MODERATOR,
            "§3{faction_rank}{faction} §l§dSrMod§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}: §d{message}",
            "§3{faction_rank}{faction} §l§dSrMod§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}", 30, 20, [
                "permission.starter",
                "permission.god",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.avatar",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("Admin", TextFormat::RESET, TextFormat::RESET . "§l§4ADMIN§r", Rank::ADMIN,
            "§3{faction_rank}{faction} §l§4ADMIN§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §c{message}",
            "§3{faction_rank}{faction} §l§4ADMIN§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}", 35, 25, [
                "permission.starter",
                "permission.god",
                "permission.avatar",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("Senior-Admin", TextFormat::RESET, TextFormat::RESET . "§l§4SENIOR ADMIN§r", Rank::SENIOR_ADMIN,
            "§3{faction_rank}{faction} §l§cSr§4Admin§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §c{message}",
            "§3{faction_rank}{faction} §l§cSr§4Admin§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}", 40, 30, [
				"permission.starter",
                "permission.god",
                "permission.avatar",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("Manager", TextFormat::RESET, TextFormat::RESET . "§l§5MANAGER§r", Rank::MANAGER,
            "§3{faction_rank}{faction} §l§5MANAGER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §d{message}",
            "§3{faction_rank}{faction} §l§5MANAGER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}", 45, 35, [
				"permission.starter",
                "permission.god",
                "permission.avatar",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
			]));
        $this->addRank(new Rank("Owner", TextFormat::RESET, TextFormat::RESET . "§l§dOWNER§r", Rank::OWNER,
            "§3{faction_rank}{faction} §l§dOWNER§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}§7: §b{message}",
            "§3{faction_rank}{faction} §l§dOWNER§r §8[§4§l{kills}§r§8] §r{tag} §r§f{player}", 50, 40, [
				"permission.starter",
                "permission.god",
                "permission.avatar",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
			]));
        $this->addRank(new Rank("YouTube", TextFormat::RESET, TextFormat::RESET . "§l§cY§fT§r", Rank::YOUTUBER,
            "§c❆ §3{faction_rank}{faction} §l§cYOU§fTUBER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§6{player}§7: §c{message}",
            "§3{faction_rank}{faction} §l§cYou§fTuber§r §r§8[§4§l{kills}§r§8]§r {tag} §r§6{player}", 20, 10, [
                "permission.starter",
                "permission.god",
                "permission.avatar",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.join.full",
                "permission.once"
            ]));
        $this->addRank(new Rank("Famous", TextFormat::RESET, TextFormat::RESET . "§l§dFAMOUS§r", Rank::FAMOUS,
            "§3{faction_rank}{faction} §l§dFAMOUS§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §d{message}",
            "§3{faction_rank}{faction} §l§dFAMOUS§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}", 25, 15, [
                "permission.starter",
                "permission.god",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.avatar",
                "permission.tier2",
                "permission.tier3",
                "permission.join.full",
                "permission.once"
                ]));
       $this->addRank(new Rank("Developer", TextFormat::RESET, TextFormat::RESET . "§l§bDEVELOPER§r", Rank::DEVELOPER,
            "§3{faction_rank}{faction} §l§bDEVELOPER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §3{message}",
            "§3{faction_rank}{faction} §l§bDEVELOPER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}", 35, 30, [
                "permission.starter",
                "permission.god",
                "permission.warlord",
                "permission.overlord",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.*",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "permission.avatar",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
        $this->addRank(new Rank("Builder", TextFormat::RESET, TextFormat::RESET . "§l§9BUILDER§r", Rank::BUILDER,
            "§3{faction_rank}{faction} §l§9BUILDER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}§7: §b{message}",
            "§3{faction_rank}{faction} §l§9BUILDER§r §r§8[§4§l{kills}§r§8]§r {tag} §r§f{player}", 45, 35, [
                "permission.starter",
                "permission.god",
                "permission.warlord",
                "permission.overlord",
                "permission.avatar",
                "permission.tier1",
                "permission.tier2",
                "permission.tier3",
                "permission.mod",
                "permission.join.full",
                "permission.staff",
                "pocketmine.*",
                "pocketmine.command.teleport",
                "pocketmine.command.gamemode",
                "bansystem.command.ban",
                "bansystem.command.banlist",
                "bansystem.command.kick",
                "bansystem.command.mute",
                "bansystem.command.mutelist",
                "bansystem.command.pardon",
                "bansystem.command.tempban",
                "bansystem.command.tempmute",
                "bansystem.command.unmute",
                "permission.once",
                "invsee"
            ]));
    }

    /**
     * @param int $identifier
     *
     * @return Rank|null
     */
    public function getRankByIdentifier(int $identifier): ?Rank {
        return $this->ranks[$identifier] ?? null;
    }

    /**
     * @return Rank[]
     */
    public function getRanks(): array {
        return $this->ranks;
    }

    /**
     * @param string $name
     *
     * @return Rank
     */
    public function getRankByName(string $name): ?Rank {
        return $this->ranks[$name] ?? null;
    }

    /**
     * @param Rank $rank
     *
     * @throws RankException
     */
    public function addRank(Rank $rank): void {
        if(isset($this->ranks[$rank->getIdentifier()]) or isset($this->ranks[$rank->getName()])) {
            throw new RankException("Attempted to override a rank with the identifier of \"{$rank->getIdentifier()}\" and a name of \"{$rank->getName()}\".");
        }
        $this->ranks[$rank->getIdentifier()] = $rank;
        $this->ranks[$rank->getName()] = $rank;
    }
}