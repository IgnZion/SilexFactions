<?php

declare(strict_types = 1);

namespace core\quest;

use Exception;

class QuestException extends Exception {

}