<?php

declare(strict_types=1);

namespace core\crate;

use core\crate\types\GreekCrate;
use core\Elemental;
use core\ElementalPlayer;
use core\translation\TranslationException;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\inventory\ChestInventory;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\tile\Chest;

class CrateListener implements Listener
{

    /** @var Elemental */
    private $core;

    /**
     * CrateListener constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core)
    {
        $this->core = $core;
    }

    /**
     * @param PlayerJoinEvent $event
     */
    public function onPlayerJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof ElementalPlayer) {
            return;
        }
        foreach ($this->core->getCrateManager()->getCrates() as $crate) {
            $crate->spawnTo($player);
        }
    }

    /**
     * @priority LOWEST
     * @param PlayerInteractEvent $event
     *
     * @throws TranslationException
     */
    public function onPlayerInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof ElementalPlayer) {
            return;
        }
        $block = $event->getBlock();
        foreach ($this->core->getCrateManager()->getCrates() as $crate) {
            if ($crate->getPosition()->equals($block->asPosition())) {
                $crate->try($player);
                $event->setCancelled();
            }
        }
    }

    /**
     * @param InventoryTransactionEvent $event
     */
    public function onInventoryTransaction(InventoryTransactionEvent $event): void
    {
        $transaction = $event->getTransaction();
        foreach ($transaction->getActions() as $action) {
            if ($action instanceof SlotChangeAction) {
                $inventory = $action->getInventory();
                if ($inventory instanceof ChestInventory && ($holder = $inventory->getHolder()) instanceof Chest) {
                    if($holder->getName() === GreekCrate::PREFIX) { //Using this hax
                        $event->setCancelled();
                        return;
                    }
                }
            }
        }
    }
}