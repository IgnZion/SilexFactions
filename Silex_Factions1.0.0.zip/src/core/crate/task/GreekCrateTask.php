<?php

namespace core\crate\task;

use core\Elemental;
use core\ElementalPlayer;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\entity\EntityIds;
use pocketmine\level\Position;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\scheduler\Task;

class GreekCrateTask extends Task
{
    /** @var ElementalPlayer */
    private $player;
    /** @var Position */
    private $pos;
    /** @var int */
    private $time = 8;

    /**
     * GreekCrateTask constructor.
     * @param ElementalPlayer $player
     * @param Position $pos
     */
    public function __construct(ElementalPlayer $player, Position $pos)
    {
        $this->player = $player;
        $this->pos = $pos;
        $this->setHandler(Elemental::getInstance()->getScheduler()->scheduleRepeatingTask($this, 20));
    }

    /**
     * @return ElementalPlayer
     */
    public function getPlayer(): ElementalPlayer
    {
        return $this->player;
    }

    /**
     * @return Position
     */
    public function getPos(): Position
    {
        return $this->pos;
    }

    public function onRun(int $currentTick)
    {
        $block = $this->getPos();
        $greekCrate = Elemental::getInstance()->getCrateManager()->getGreekCrate();
        $player = $this->getPlayer();
        if ($player instanceof ElementalPlayer) {
            $pk = new AddActorPacket();
            $pk->type = AddActorPacket::LEGACY_ID_MAP_BC[EntityIds::LIGHTNING_BOLT];
            $pk->entityRuntimeId = Entity::$entityCount++;
            $pk->position = $block->add(0, 1);
            $pk->yaw = 0;
            $pk->pitch = 0;
            $player->sendDataPacket($pk);
            if (--$this->time <= 0) {
                $greekCrate->getReward()->getCallback()($player);
                $player->getLevelNonNull()->setBlock($block, Block::get(Block::AIR), true, true);
                Elemental::getInstance()->getScheduler()->cancelTask($this->getTaskId());
            }
        } else {
            $block->getLevel()->dropItem($block->add(0, 1), $greekCrate->getReward()->getItem());
            $player->getLevelNonNull()->setBlock($block, Block::get(Block::AIR), true, true);
            Elemental::getInstance()->getScheduler()->cancelTask($this->getTaskId());
        }
    }
}
