<?php

declare(strict_types = 1);

namespace core\utils;

use Exception;

class UtilsException extends Exception {

}