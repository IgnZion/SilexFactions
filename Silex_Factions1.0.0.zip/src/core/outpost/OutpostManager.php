<?php

namespace core\outpost;


use core\Elemental;
use core\ElementalPlayer;
use core\outpost\task\OutpostCapturetask;
use core\outpost\task\OutpostParticleTask;
use core\translation\Translation;
use core\utils\FloatingTextParticle;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\level\Position;
use pocketmine\math\AxisAlignedBB;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class OutpostManager implements Listener
{
    /** @var Elemental  */
    private $core;

    /** @var array|Outpost  */
    public $outpost = [];

    public function __construct(Elemental $elemental)
    {
        $elemental->getScheduler()->scheduleRepeatingTask(new OutpostParticleTask(),20);
        foreach ($this->outpost as $name => $class) {
            if (!$class instanceof Outpost) return;
            $elemental->getServer()->loadLevel($class->getLevel());
        }
        $elemental->getServer()->getPluginManager()->registerEvents($this,$elemental);
    }


    public function sendTop() {
       foreach ($this->outpost as $datum => $class) {
           for ($i = 1; $i <= 5;) {
               ksort($class["time"]);

               switch ($i) {
                   case 1:
                       return TextFormat::RESET.TextFormat::GREEN;
                       break;

                   case 2:
                       return TextFormat::RESET.TextFormat::GOLD;
                       break;


                   case 3:
                       return TextFormat::RESET.TextFormat::RED;
                       break;

                   case 4 || 5:
                       return TextFormat::RESET.TextFormat::DARK_RED;
                       break;
               }
               $i++;

               return "\n".$i.TextFormat::RESET.TextFormat::AQUA." {$datum["Faction"]} with a ".gmdate("d:H:i:s",$datum["time"])."at "."§".mt_rand(1,10).$datum."$datum";
           }
       }
       return "[OUTPOST]: Error! This is being caused at Line 42 - 70 in the sendTop() function! Cause: Invalid faction name OR invalid faction XUID (restarting server can fix this!)";
    }

    public function playermove(PlayerMoveEvent $event) {
        $player = $event->getPlayer();

        if (!$player instanceof ElementalPlayer) return;
        foreach ($this->outpost as $names => $class) {
            if (!$class instanceof Outpost) return;
            if ($class->inBox($player)) {
                $this->core->getScheduler()->scheduleRepeatingTask(new OutpostCapturetask($player),20);
            }else{
                $task = new OutpostCapturetask($player);
                $this->core->getScheduler()->cancelTask($task->getTaskId());
            }
        }
    }


    public function create(ElementalPlayer $player,$name,Position $float,$msg,Position $position1,Position $pos2) {
        foreach ($this->outpost as $names) {
            if ($names !== $name) {
                $this->outpost[$name] = new Outpost(
                    new FloatingTextParticle($float,$name,$msg),$player->getLevel()->getName(),$name,$position1,$pos2
                );
                $this->outpost[$name] = ["time" => 0,"faction" => null];
                $player->sendMessage(Translation::GREEN."Successfully Created a Outpost named $name");
            }
            $player->sendMessage(Translation::RED."Outpost named $name is existed already!");
        }
    }

    public function editx(ElementalPlayer $player,string $name) {
        foreach ($this->outpost as $names => $stuffs) {
            if (!$stuffs instanceof Outpost) return;
            if ($names === $name) {

                $this->outpost[$names] = new Outpost($stuffs->getFloatingText(), $stuffs->getLevel(), $names, new Position($player->getFloorX(), $stuffs->getPosition()->getY(), $stuffs->getPosition()->getZ()), new Position($player->getX(), $stuffs->getPosition()->getY(), $stuffs->getPosition2()->getZ()));
            }

            $player->sendMessage(Translation::RED."Outpost named $name Can't be found");
        }
    }

    public function exdity(ElementalPlayer $player,string $name) {
        foreach ($this->outpost as $names => $stuffs) {
            if (!$stuffs instanceof Outpost) return;
            if ($names === $name) {

                $this->outpost[$names] = new Outpost($stuffs->getFloatingText(), $stuffs->getLevel(), $names, new Position($stuffs->getPosition()->getX(), $player->getY(), $stuffs->getPosition()->getZ()), new Position($stuffs->getPosition2()->getX(), $player->getY(), $stuffs->getPosition2()->getZ()));
            }

            $player->sendMessage(Translation::RED."Outpost named $name Can't be found");
        }
    }

    public function editz(ElementalPlayer $player,string  $name) {
        foreach ($this->outpost as $names => $stuffs) {
            if (!$stuffs instanceof Outpost) return;
            if ($names === $name) {

                $this->outpost[$names] = new Outpost($stuffs->getFloatingText(), $stuffs->getLevel(), $names, new Position($stuffs->getPosition()->getX(), $stuffs->getPosition()->getY(), $player->getZ()), new Position($stuffs->getPosition2()->getX(), $stuffs->getPosition2()->getY(), $player->getZ()));
            }

            $player->sendMessage(Translation::RED."Outpost named $name Can't be found");
        }
    }

    public function editflp(ElementalPlayer $player,string $name) {
        foreach ($this->outpost as $names => $stuffs) {
            if (!$stuffs instanceof Outpost) return;
            if ($names === $name) {

                $this->outpost[$names] = new Outpost(new FloatingTextParticle($player->asPosition(),$names,$stuffs->getFloatingText()->getMessage()), $stuffs->getLevel(), $names, new Position($stuffs->getPosition()->getX(), $stuffs->getPosition()->getY(),$stuffs->getPosition()->getZ()), new Position($stuffs->getPosition2()->getX(), $stuffs->getPosition2()->getY(), $stuffs->getPosition2()->getZ()));
            }
            $player->sendMessage(Translation::RED."Outpost named $name Can't be found");
        }
    }

    public function delete(string $name) {
        foreach ($this->outpost as $names) {
            if ($name === $names) {

                Elemental::debug("Deleting $name...");
                sleep(2);
                unset($this->outpost[$name]);
                Elemental::debug("Successfully Delete $name...");
            }
            Elemental::debug("Oopx Can't find outpost named $name :".implode(",",$this->getOutposts()));
        }
    }

    public function getOutposts() {
        return $this->outpost;
    }
}