<?php

namespace core\outpost;


use core\command\utils\Command;
use core\Elemental;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AnimatePacket;
use pocketmine\utils\TextFormat;

class OutpostCommand extends Command
{

    public function __construct()
    {
        parent::__construct('outpost', 'Outposts Checker', '', ['']);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender instanceof ElementalPlayer) return;
        if (!$args[0]) {
            foreach (Elemental::getInstance()->getOutpostManager()->outpost as $name => $class) {
                if (!$class instanceof Outpost) return;;
                $msg = TextFormat::AQUA.$name." at {$class->getPosition()->asPosition()} Captured By: ".$class["faction"] = null ? $class["faction"] : "None";
                $msg .= $sender->isOp() ?  "$msg\n/outpost create/delete/list" : "$msg";

                $sender->sendMessage($msg);
            }
        }
            //switch ($args[1]){
                //case "top":
                   // $sender->sendMessage(Elemental::getInstance()->getOutpostManager()->sendTop());
                    //break;
                //case "create" :
                    //if (!$sender->isOp()) {
                   //     $sender->sendMessage(Translation::getMessage("noPermission"));
                   // }
                   /// if (!isset($args[0]) || !isset($args[1])) {
      //                  $sender->sendMessage(Translation::RED."/outpost create {name} {floatingtext msg} ");
      //              }
               //     Elemental::getInstance()->getOutpostManager()->create($sender,$args[0],$sender->asPosition(),$args[1],$sender->asPosition(),$sender->asPosition());
      //              break;
      //   ////       case "list" :
      //              if (!$sender->isOp()) {
      //                  $sender->sendMessage(Translation::getMessage("noPermission"));
      //              }
      //              foreach (Elemental::getInstance()->getOutpostManager()->outpost as $name => $class) {
       //                 $msg = Elemental::getInstance()->getOutpostManager()->getOutposts();
      ///                  $sender->sendMessage(TextFormat::AQUA."Outpost list :".implode(",",$msg));
                    //}
       //             break;

      ///          case "delete":
       ///             if(!$sender->isOp()) {
       //                 $sender->sendMessage(Translation::getMessage("noPermission"));
       ///             }
        //            if (!isset($args[0])) {
        //                $sender->sendMessage(Translation::RED."/outpost delete {name} <");
        //            }
        //            Elemental::getInstance()->getOutpostManager()->delete($args[0]);
        //            break;

        //        case "edit":
        //            if (!$sender->isOp()) {
        //                $sender->sendMessage(Translation::getMessage("noPermission"));
        ///           }
        ///           if (!isset($args[0]) || !isset($args[1])) {
         //               $sender->sendMessage(Translation::RED."/outpost edit {name}{ args...}");
          //          }
         //           switch ($args[1]){
         //               case "x":
         //                   Elemental::getInstance()->getOutpostManager()->editx($sender,$args[0]);
         //                   break;

         //               case "y":
               //             Elemental::getInstance()->getOutpostManager()->exdity($sender,$args[0]);
         //                   break;
//

         //               case "z":
          //                  Elemental::getInstance()->getOutpostManager()->editz($sender,$args[0]);
          //                  break;
//
                       // case "flp":
                            //Elemental::getInstance()->getOutpostManager()->editflp($sender,$args[0]);
                            //break;
                        //default:
                            //$sender->sendMessage(Translation::RED."Invalid arguments : x,y,z,flp");
                           // break;
                    //}
                    //break;
        //}
    }
}