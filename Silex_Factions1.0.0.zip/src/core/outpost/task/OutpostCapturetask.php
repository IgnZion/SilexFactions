<?php

namespace core\outpost\task;




use core\Elemental;
use core\ElementalPlayer;
use core\item\CustomItem;
use core\item\types\CrateKeyNote;
use core\item\types\SellWand;
use core\outpost\Outpost;
use core\outpost\OutpostManager;
use core\translation\Translation;
use pocketmine\item\Item;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class OutpostCapturetask extends Task
{
    private $player;
    /**
     * @var int
     */
    private $time = 0;

    public function __construct(ElementalPlayer $player)
    {
        $this->player = $player;
    }

    function onRun(int $currentTick)
    {
        foreach (Elemental::getInstance()->getOutpostManager()->outpost as $names => $class) {
            // the easiest way :wink:
            if(!$class instanceof Outpost) return;
            if ($this->player->getFaction() === $class["faction"]) {
                $this->player->sendMessage(Translation::GREEN."Your Faction Captured this Outpost Already!");
                Elemental::getInstance()->getOutpostManager()->outpost[$names] = ["time" => $class["time"] + 1];
                Elemental::getInstance()->getScheduler()->scheduleRepeatingTask(new OutpostAddStrTask($this->player),20);
                Elemental::getInstance()->getScheduler()->cancelTask($this->getTaskId());
            }
            $realcapturebar = str_repeat(TextFormat::GREEN.":",$this->time).str_repeat(TextFormat::RED.":",$this->time);
            $this->player->sendTip(TextFormat::GREEN."Capturing ... {$class->getOutpostName()}".PHP_EOL." $realcapturebar");
            if ($this->time <= 100) {
                if ($this->player->getFaction() === null) {
                    Elemental::getInstance()->getServer()->broadcastMessage(Translation::GREEN."Solo Reward for {$this->player->getName()} Wooo :eyes:");
                }
                if ($this->player->getFaction() !== $class["faction"]) {
                    Server::getInstance()->broadcastMessage(Translation::GREEN."Outpost {$class->getOutpostName()} New Captures from {$this->player->getFaction()} || {$this->player->getName()}");
                    Elemental::getInstance()->getOutpostManager()->outpost[$names] = ["faction" => $this->player->getFaction()];
                }
                Elemental::getInstance()->getScheduler()->cancelTask($this->getTaskId());

            }
        }
        $this->time++;
    }
}