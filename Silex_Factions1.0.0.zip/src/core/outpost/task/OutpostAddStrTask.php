<?php

namespace core\outpost\task;



use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\scheduler\Task;

class OutpostAddStrTask extends Task
{
    private $min = 60;
    /** @var ElementalPlayer  */
    private $player;

    public function __construct(ElementalPlayer $player)
    {
        $this->player = $player;
    }

    public function onRun(int $currentTick)
    {
        if ($this->min >= 0) {
            $this->player->getFaction()->addStrength(7);
            foreach ($this->player->getFaction()->getOnlineMembers() as $ppl) {
                $ppl->sendMessage(Translation::GREEN."15+ STR for Capturing the Outpost for 1 minute!");
            }
            $this->min++;
        }
        $this->min--;
    }
}