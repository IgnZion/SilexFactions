<?php

namespace core\outpost\task;


use core\Elemental;
use core\ElementalPlayer;
use core\outpost\Outpost;
use core\outpost\OutpostManager;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\Position;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;

class OutpostParticleTask extends Task
{
    public function __construct()
    {

    }

    public function onRun(int $currentTick)
    {
        foreach (Elemental::getInstance()->getOutpostManager()->outpost as $data => $class) {
            if (!$class instanceof Outpost) return;
            foreach (Elemental::getInstance()->getServer()->getLevelByName($class->getLevel())->getPlayers() as $ppl) {
                if (!$ppl instanceof ElementalPlayer) return;

                $rgbColor = array();

                foreach(array('r', 'g', 'b') as $color){
                    $rgbColor[$color] = mt_rand(0, 255);
                }
                var_dump($rgbColor['r']);

                foreach (Elemental::getInstance()->getOutpostManager()->outpost as $name => $class) {
                    if (!$class instanceof Outpost) return;
                    $class->getFloatingText()->update();
                }
                $ppl->getLevel()->addParticle(new DustParticle($this->box(),$rgbColor['r'],$rgbColor['g'],$rgbColor['b']));
            }
        }

    }

    public  function box()  {
        foreach (Elemental::getInstance()->getOutpostManager()->outpost as $name => $class) {
            if (!$class instanceof Outpost) return false;
            $pos1 = new Position($class->getPosition()->getX(),$class->getPosition()->getY(),$class->getPosition()->getZ(),$class->getPosition()->getLevel());
            $pos2 = new Position($class->getPosition2()->getX(),$class->getPosition2()->getY(),$class->getPosition2()->getZ());
            $abb = new AxisAlignedBB($pos1->getX(),$pos1->getY(),$pos1->getZ(),$pos2->getX(),$pos2->getY(),$pos2->getZ());
            return new Vector3($abb->minX <=  $abb->maxX,$abb->minY  <= $abb->maxY,$abb->minZ <= $abb->maxZ);
        }
    }
}