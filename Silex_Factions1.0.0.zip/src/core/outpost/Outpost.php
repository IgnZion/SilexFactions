<?php

namespace core\outpost;


use core\ElementalPlayer;
use core\utils\FloatingTextParticle;
use pocketmine\level\Position;
use pocketmine\math\AxisAlignedBB;
use pocketmine\Player;
use pocketmine\Server;

class Outpost
{
    /** @var string  */
    private $name;

    /** @var Position  */
    private $position;

    /** @var Position */
    private $position2;

    /** @var FloatingTextParticle  */
    private $floatingText;

    /** @var string  */
    private $level;

    public function __construct(string $floatingText,string $level,string $name,Position $position,Position $position2)
    {
        $this->level = $level;
        $this->floatingText = $floatingText;
        $this->position2 = $position2;
        $this->position = $position;
        $this->name = $name;
    }
    public function getPosition() {
        return $this->position;
    }

    public function getPosition2() {
        return $this->position2;
    }

    public function getLevel() {
        return $this->level;
    }

    public function getOutpostName() {
        return $this->name;
    }

    public function getFloatingText() {
        return $this->floatingText;
    }

    public function inBox(ElementalPlayer $player): bool
    {
        $x = $player->getX();
        $y = $player->getY();
        $z = $player->getZ();
        $pos1 = $this->position;
        $pos2 = $this->position2;
        $aab = new AxisAlignedBB($pos1->getX(),$pos1->getY(),$pos1->getZ(),$pos2->getX(),$pos2->getY(),$pos2->getZ());
        return $aab->minX <= $x && $x <= $aab->maxX && $aab->minY <= $y && $y <= $aab->maxY && $aab->minZ <= $z && $z && $aab->maxZ;
    }
}
