<?php

namespace core\gamble;

use core\Elemental;
use core\ElementalPlayer;

class GambleManager {

    /** @var Elemental */
    private $core;

    /** @var int[] */
    private $coinFlips = [];

    /** @var string[] */
    private $coinFlipRecord = [];

    /**
     * GambleManager constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
        $this->core->getServer()->getPluginManager()->registerEvents(new GambleListener($core), $core);
    }

    /**
     * @return int[]
     */
    public function getCoinFlips(): array {
        return $this->coinFlips;
    }

    /**
     * @param ElementalPlayer $player
     *
     * @return int|null
     */
    public function getCoinFlip(ElementalPlayer $player): ?int {
        return $this->coinFlips[$player->getName()] ?? null;
    }

    /**
     * @param ElementalPlayer $player
     * @param int           $amount
     */
    public function addCoinFlip(ElementalPlayer $player, int $amount): void {
        if(isset($this->coinFlips[$player->getName()])) {
            return;
        }
        $this->coinFlips[$player->getName()] = $amount;
    }

    /**
     * @param ElementalPlayer $player
     */
    public function removeCoinFlip(ElementalPlayer $player): void {
        if(!isset($this->coinFlips[$player->getName()])) {
            return;
        }
        unset($this->coinFlips[$player->getName()]);
    }

    /**
     * @param ElementalPlayer $player
     * @param $wins
     * @param $losses
     */
    public function getRecord(ElementalPlayer $player, &$wins, &$losses): void {
        $record = $this->coinFlipRecord[$player->getName()];
        $reward = explode(":", $record);
        $wins = $reward[0];
        $losses = $reward[1];
    }

    /**
     * @param ElementalPlayer $player
     */
    public function createRecord(ElementalPlayer $player): void {
        $this->coinFlipRecord[$player->getName()] = "0:0";
    }

    /**
     * @param ElementalPlayer $player
     */
    public function addWin(ElementalPlayer $player): void {
        if(!isset($this->coinFlipRecord[$player->getName()])){
            $this->coinFlipRecord[$player->getName()] = "0:0";
        }
        $record = $this->coinFlipRecord[$player->getName()];
        $reward = explode(":", $record);
        $wins = intval($reward[0]) + 1;
        $losses = $reward[1];
        $this->coinFlipRecord[$player->getName()] = "$wins:$losses";
    }

    /**
     * @param ElementalPlayer $player
     */
    public function addLoss(ElementalPlayer $player): void {
        $record = $this->coinFlipRecord[$player->getName()];
        $reward = explode(":", $record);
        $wins = $reward[0];
        $losses = $reward[1] + 1;
        $this->coinFlipRecord[$player->getName()] = "$wins:$losses";
    }
}