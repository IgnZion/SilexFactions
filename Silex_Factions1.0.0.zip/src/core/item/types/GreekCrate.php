<?php

namespace core\item\types;

use core\item\CustomItem;
use pocketmine\nbt\tag\CompoundTag;
use \core\crate\types\GreekCrate as Crate;

class GreekCrate extends CustomItem {

    const GREEK_CRATE = "Greek Crates";

    /**
     * GreekCrate constructor.
     */
    public function __construct() {
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setString(self::GREEK_CRATE, self::GREEK_CRATE);
        $tag->setString("UniqueId", uniqid());
        parent::__construct(self::CHEST, Crate::PREFIX, []);
    }
}