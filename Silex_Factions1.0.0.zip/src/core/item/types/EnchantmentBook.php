<?php

declare(strict_types = 1);

namespace core\item\types;

use core\item\CustomItem;
use core\item\ItemManager;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class EnchantmentBook extends CustomItem {

    const ENCHANTMENT = "Enchantment";

    /**
     * EnchantmentBook constructor.
     *
     * @param Enchantment $enchantment
     */
    public function __construct(Enchantment $enchantment) {
        $customName = TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "{$enchantment->getName()} Enchantment Book";
        $lore = [];
        $lore[] = "";
        $lore[] = TextFormat::GRAY . "Drag n' Drop the book into the valid Item\n!" . TextFormat::GRAY . "To apply the enchantment!";
        $lore[] = "";
        $lore[] = TextFormat::GOLD . "For Info About the book type (/ceinfo) in chat!";
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setInt(self::ENCHANTMENT, $enchantment->getId());
        $tag->setString("UniqueId", uniqid());
        parent::__construct(self::ENCHANTED_BOOK, $customName, $lore);
    }

    public function getMaxStackSize(): int{
        return 1;
    }
}
