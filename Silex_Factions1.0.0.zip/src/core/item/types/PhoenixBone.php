<?php


namespace core\item\types;

use core\item\CustomItem;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\TextFormat;

class PhoenixBone extends CustomItem
{
    const PHOENIX_BONE = "Phoenix";

    /**
     * PhoenixBone constructor.
     */
    public function __construct() {
        $customName = TextFormat::RESET . TextFormat::GOLD . TextFormat::BOLD . "Phoenix Angel Bone";
        $lore = ["",
            TextFormat::YELLOW . "An angelic bone gathered from the carcarus of a fallen " . TextFormat::GOLD . "Phoenix" . TextFormat::RESET,
            TextFormat::YELLOW . "Summons an Angel Hero who strives to avenge its fallen brother",
            TextFormat::RESET . " ",
            TextFormat::GOLD . "Damage: " . TextFormat::GRAY . "200",
            TextFormat::GOLD . "Health: " . TextFormat::GRAY . "1000"];
        $this->setNamedTagEntry(new CompoundTag(self::CUSTOM));
        /** @var CompoundTag $tag */
        $tag = $this->getNamedTagEntry(self::CUSTOM);
        $tag->setString(self::PHOENIX_BONE, self::PHOENIX_BONE);
        $tag->setString("UniqueId", uniqid());
        parent::__construct(Item::BONE, $customName, $lore);
    }
}
