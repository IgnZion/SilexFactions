<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class HordEnchantment extends Enchantment {

    /**
     * HordEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::HORD, "Hord", self::RARITY_MYTHIC, "Spawn a hord of warriors, blind your opponent and poison them and regenerate health.", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 300);
            $chance = $level * 3;
            if($chance >= $random) {
				$randomDamage = mt_rand(1, 6);
				$entity->setHealth($entity->getHealth() - $randomDamage);
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 10 * 20, 1));
				$entity->addEffect(new EffectInstance(Effect::getEffect(Effect::POISON), 10 * 20, 1));
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 5 * 20, 1));
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::POISON), 5 * 20, 1));
				$damager->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 10 * 20, 1));
                $entity->sendMessage(Translation::ORANGE . "Your opponent's Hord has been Spawned and they are now regenerating health!");
                $damager->sendMessage(Translation::ORANGE . "Your Hord has been Spawned and you are now regenerating health!");
            }
        };
    }
}