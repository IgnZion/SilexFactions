<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class CloverineEnchantment extends Enchantment {

    /**
     * CloverineEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::CLOVERINE, "Cloverine", self::RARITY_RARE, "Earn money by just hitting an entity (Player, Mob etc)", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
			$entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
			}
			if($event->isCancelled()){
				return;
			}
            $random = mt_rand(1, 200);
            $chance = $level * 3;
            if($chance >= $random) {
				$randomMoney = mt_rand(100, 500);
				$randomXp = mt_rand(20, 40) * $level;
                $entity->sendMessage(Translation::ORANGE . "Your opponent is Cloving!");
				$damager->sendMessage(Translation::ORANGE . "You are Cloving!");
				$damager->sendPopup("§a+ $$randomMoney");
				$damager->addXp($randomXp);
				$damager->addToBalance($randomMoney);
            }
        };
    }
}