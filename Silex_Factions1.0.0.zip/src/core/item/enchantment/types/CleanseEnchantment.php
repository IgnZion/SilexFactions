<?php

declare(strict_types = 1);

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\Durable;
use pocketmine\Player;

class CleanseEnchantment extends Enchantment {

    /**
     * CleanseEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::CLEANSE, "Cleanse", self::RARITY_RARE, "Have a chance to repair random peices of your armor mid combat but do 50% less damage for 2 seconds when it activates", self::DAMAGE, self::SLOT_SWORD, 5);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
			$entity = $event->getEntity();
			$damager = $event->getDamager();
            if(!$damager instanceof Player) {
                return;
			}
            $repair = mt_rand(1, 20) * $level;
            foreach($damager->getArmorInventory()->getContents() as $armor) {
                if($armor instanceof Durable) {
					$armor->setDurability($repair);
					$event->setBaseDamage($event->getBaseDamage() - 30);
					$damager->sendMessage("§8§l(§6!§8) §r§7Cleansing has activated");
                }
            }
            return;
        };
    }
}