<?php

namespace core\item\enchantment\types;

use core\item\enchantment\Enchantment;
use core\ElementalPlayer;
use core\translation\Translation;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class RageEnchantment extends Enchantment {

    /**
     * RageEnchantment constructor.
     */
    public function __construct() {
        parent::__construct(self::RAGE, "Rage", self::RARITY_MYTHIC, "Have a chance to put your rage into your opponent and do lots of damage.", self::DAMAGE, self::SLOT_SWORD, 10);
        $this->callable = function(EntityDamageByEntityEvent $event, int $level) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if((!$entity instanceof ElementalPlayer) or (!$damager instanceof ElementalPlayer)) {
                return;
            }
            $random = mt_rand(1, 300);
            $chance = $level * 3;
            if($chance >= $random) {
				$randomDamage = mt_rand(2, 6);
				$entity->setHealth($entity->getHealth() - $randomDamage);
                $entity->sendMessage(Translation::ORANGE . "Your opponent is Raging!");
                $damager->sendMessage(Translation::ORANGE . "You are Raging!");
            }
        };
    }
}