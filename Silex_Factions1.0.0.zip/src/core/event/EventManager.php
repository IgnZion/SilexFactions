<?php

declare(strict_types = 1);

namespace core\event;

use core\event\christmas\PresentGiftChooser;
use core\Elemental;

class EventManager {

    /** @var Elemental */
    private $core;

    /** @var PresentGiftChooser */
    private static $giftChooser;

    /**
     * ItemManager constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
        self::$giftChooser = new PresentGiftChooser();
    }

    /**
     * @return PresentGiftChooser
     */
    public static function getGiftChooser(): PresentGiftChooser {
        return self::$giftChooser;
    }
}