<?php

declare(strict_types = 1);

namespace core\command\types;

use core\command\utils\Command;
use core\ElementalPlayer;
use core\rank\Rank;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;

class RankUpCommand extends Command {

    /**
     * RankUpCommand constructor.
     */
    public function __construct() {
        parent::__construct("rankup", "Rank up", "/rankup", ["ru"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if(!$sender instanceof ElementalPlayer) {
            $sender->sendMessage(Translation::getMessage("noPermission"));
            return;
        }
        $rank = $sender->getRank();
        switch($rank->getIdentifier()) {
            case Rank::ADVENTURER:
                $price = 200000;
                $rankId = Rank::IVARA;
                break;
            case Rank::IVARA:
                $price = 1000000;
                $rankId = Rank::MIDAS;
                break;
            case Rank::MIDAS:
                $price = 5000000;
                $rankId = Rank::APHRODITE;
                break;
            case Rank::APHRODITE:
                $price = 20000000;
                $rankId = Rank::EREBUS;
                break;
            default:
                if(!$sender->hasPermission("permission.avatar")) {
                    $price = 200000;
                    $permission = "permission.knight";
                }
                elseif(!$sender->hasPermission("permission.janus")) {
                    $price = 1000000;
                    $permission = "permission.wizard";
                }
                elseif(!$sender->hasPermission("permission.iris")) {
                    $price = 5000000;
                    $permission = "permission.king";
                }
                elseif(!$sender->hasPermission("permission.midas")) {
                    $price = 20000000;
                    $permission = "permission.mystic";
                }
                else {
                    $price = null;
                    $permission = null;
                }
        }
        if((!isset($price)) or $price === null) {
            $sender->sendMessage(Translation::getMessage("maxRank"));
            return;
        }
        if($price > $sender->getBalance()) {
            $sender->sendMessage(Translation::getMessage("notEnoughMoneyRankUp", [
                "amount" => TextFormat::RED . "$$price"
            ]));
            return;
        }
        if(isset($rankId)) {
            $sender->subtractFromBalance($price);
            $sender->setRank(($rank = $sender->getCore()->getRankManager()->getRankByIdentifier($rankId)));
            $this->getCore()->getServer()->broadcastMessage(Translation::getMessage("rankUp", [
                "name" => TextFormat::AQUA . $sender->getName(),
                "rank" => TextFormat::YELLOW . $rank->getName()
            ]));
        }
        elseif(isset($permission)) {
            $sender->subtractFromBalance($price);
            $sender->getSession()->addPermissions((string)$permission);
            $rank = ucfirst(explode(".", $permission)[1]);
            $this->getCore()->getServer()->broadcastMessage(Translation::getMessage("rankUp", [
                "name" => TextFormat::AQUA . $sender->getName(),
                "rank" => TextFormat::YELLOW . $rank
            ]));
        }
        else {
            $sender->sendMessage(Translation::getMessage("errorOccurred"));
        }
    }
}
