<?php

declare(strict_types = 1);

namespace core\command\types;

use core\command\task\TeleportTask;
use core\command\types\TeleportAskCommand;
use core\command\utils\Command;
use core\ElementalPlayer;
use core\translation\Translation;
use core\translation\TranslationException;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;

class TpacceptCommand extends Command {

    /**
     * TeleportAskCommand constructor.
     */
    public function __construct() {
        parent::__construct("tpaccept", "Accept someones teleportation request.", "/tpaccept <player>", ["tpaccept"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     *
     * @throws TranslationException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if(!$sender instanceof ElementalPlayer) {
            $sender->sendMessage(Translation::getMessage("noPermission"));
            return;
        }
		if($sender->isInStaffMode()){
			$sender->sendMessage("§l§8(§a!§8)§r §cYou can not use this while in staff mode");
			return;
		}
		if(!isset($args[0])) {
            $sender->sendMessage(Translation::getMessage("usageMessage", [
                "usage" => $this->getUsage()
            ]));
            return;
        }
		$player = $this->getCore()->getServer()->getPlayer($args[0]);
        if(!$player instanceof ElementalPlayer) {
            $sender->sendMessage(Translation::getMessage("invalidPlayer"));
            return;
        }
        if($sender->isTeleporting() === true) {
            $sender->sendMessage(Translation::getMessage("alreadyTeleporting", [
                "name" => "You are"
            ]));
            return;
        }
        if($player->isTeleporting() === true) {
            $sender->sendMessage(Translation::getMessage("alreadyTeleporting", [
                "name" => "{$player->getName()} is"
            ]));
            return;
        }
        if($sender instanceof ElementalPlayer) {
                if(!$player->isRequestingTeleport($sender)) {
                    $sender->sendMessage(Translation::getMessage("didNotRequest"));
                    return;
                }
                $player->removeTeleportRequest($sender);
                $player->sendMessage(Translation::getMessage("acceptRequest"));
                $this->getCore()->getScheduler()->scheduleRepeatingTask(new TeleportTask($player, $sender, 5), 20);
                return;
        }
    }
}