<?php

declare(strict_types = 1);

namespace core\command\forms;

use core\libs\form\CustomForm;
use core\libs\form\element\Label;
use pocketmine\utils\TextFormat;

class ChangeLogForm extends CustomForm {

    /**
     * ChangeLogForm constructor.
     */
    public function __construct() {
        $title = TextFormat::BOLD . TextFormat::AQUA . "Change Log";
        $elements = [];
        $elements[] = new Label("Changes",  "This year is looking good so far!\nImplemented an AntiCheat\nFixed Bugs\nFinished the core\nReleased Beta!");
        parent::__construct($title, $elements);
    }
}