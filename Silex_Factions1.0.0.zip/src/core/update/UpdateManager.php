<?php

declare(strict_types = 1);

namespace core\update;

use core\Elemental;
use core\ElementalPlayer;
use core\update\task\UpdateTask;
use core\utils\UtilsException;
use pocketmine\item\Armor;
use pocketmine\utils\TextFormat;

class UpdateManager {

    /** @var Elemental */
    private $core;

    /**
     * UpdateManager constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
        $core->getScheduler()->scheduleRepeatingTask(new UpdateTask($core), 1);
    }

    /**
     * @param ElementalPlayer $player
     *
     * @throws UtilsException
     */
    public function updateScoreboard(ElementalPlayer $player): void {
        $scoreboard = $player->getScoreboard();
        if($scoreboard === null) {
            return;
        }
        if($scoreboard->isSpawned() === false) {
            $scoreboard->spawn($this->core->scoreBoardTitle);
            return;
        }

        if (!$player->isUsingPVPHUD()) {
            if (count($scoreboard->getLines()) > count($this->core->pvpScoreBoardLines)) {
                $scoreboard->removeLine(array_key_last($this->core->pvpScoreBoardLines));
            }
            foreach ($this->core->pvpScoreBoardLines as $i => $line) {
                $scoreboard->setScoreLine($i+1, TextFormat::colorize($this->getTagValue($line, $player)));
            }
        } else {
            if (count($scoreboard->getLines()) > count($this->core->scoreBoardLines)) {
                $scoreboard->removeLine(array_key_last($this->core->scoreBoardLines));
            }
            foreach ($this->core->scoreBoardLines as $i => $line) {
                $scoreboard->setScoreLine($i+1, TextFormat::colorize($this->getTagValue($line, $player)));
            }
        }
    }

    private function getTagValue(string $line, ElementalPlayer $player): string {

        $helmet = $player->getArmorInventory()->getHelmet();
        $chestplate = $player->getArmorInventory()->getChestplate();
        $leggings = $player->getArmorInventory()->getLeggings();
        $boots = $player->getArmorInventory()->getBoots();

        $tags = [
            "{rank}" => $player->getRank()->getColoredName(),
            "{player}" => $player->getName(),
            "{faction}" => $player->getFaction() == null ? "No Faction" : $player->getFaction()->getName(),
            "{kills}" => $player->getKills(),
            "{xp}" => $player->getXpLevel(),
            "{bal}" => "$".number_format($player->getBalance()),
            "{lb}" => $player->getLuckyBlocksMined(),
            "{helmet}" => $helmet instanceof Armor ? $helmet->getMaxDurability() - $helmet->getDamage() : "None.",
            "{chestplate}" => $chestplate instanceof Armor ? $chestplate->getMaxDurability() - $chestplate->getDamage() : "None",
            "{leggings}" => $leggings instanceof Armor ? $leggings->getMaxDurability() - $leggings->getDamage() : "None",
            "{boots}" => $boots instanceof Armor ? $boots->getMaxDurability() - $boots->getDamage() : "None",
            "{gap_cooldown}" => $this->core->getCombatManager()->getGoldenAppleCooldown($player),
            "{egap_cooldown}" => $this->core->getCombatManager()->getGodAppleCooldown($player),
            "{e_cooldown}" => $this->core->getCombatManager()->getEnderPearlCooldown($player)
        ];

        $string = $line;
        foreach ($tags as $tag => $value) {
            $string = str_replace($tag, $value, $string);
        }

        return $string;
    }
}
