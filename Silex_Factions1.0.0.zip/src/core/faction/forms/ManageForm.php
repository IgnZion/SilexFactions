<?php

namespace core\command\forms;

use core\Elemental;
use core\ElementalListener;
use core\ElementalPlayer;
use core\libs\form\MenuForm;
use core\libs\form\MenuOption;
use core\translation\Translation;
use pocketmine\entity\Skin;
use core\faction\Faction;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use core\faction\command\subCommands\FactionManagerCommand;

class ManageForm extends MenuForm
{
    public function __construct()
    {
        $title = TextFormat::AQUA.TextFormat::BOLD."Faction manager";
        $text = TextFormat::AQUA."Select a option";
        $options[] = new MenuOption("Information");
		$options[] = new MenuOption("Promote a member");
		$options[] = new Menuoption("Demote a user");
		$options[] = new MenuOption("Claim this chunk");
		$options[] = new MenuOption("Member list");
		$options[] = new MenuOption("Deposit money");
		$options[] = new MenuOption("Delete your faction");
        parent::__construct($title, $text, $options);
    }

    public function onSubmit(Player $player, int $selectedOption): void
    {
        if (!$player instanceof ElementalPlayer) {
            return;
		}
		if($player->getFaction() == null){
			$player->sendMessage(Translation::getMessage("beInFaction"));
			return;
		}
        $option = $this->getOption($selectedOption)->getText();
        if ($option === "Information") {
			$faction = $player->getFaction();
			$player->sendMessage(TextFormat::DARK_RED . TextFormat::BOLD . $faction->getName() . TextFormat::RESET . TextFormat::DARK_GRAY . " [" . TextFormat::GRAY . count($faction->getMembers()) . "/" . Faction::MAX_MEMBERS . TextFormat::DARK_GRAY . "]");
        	$role = Faction::LEADER;
        	$name = $faction->getName();
        	$stmt = $this->getCore()->getMySQLProvider()->getDatabase()->prepare("SELECT username FROM players WHERE faction = ? and factionRole = ?");
        	$stmt->bind_param("si", $name, $role);
        	$stmt->execute();
        	$stmt->bind_result($leader);
        	$stmt->fetch();
        	$stmt->close();
        	$members = [];
        	foreach($faction->getMembers() as $member) {
        	    if(($player = $this->getCore()->getServer()->getPlayer($member)) !== null) {
        	        $members[] = TextFormat::GREEN . $player->getName();
        	        continue;
        	    }
        	    $members[] = TextFormat::WHITE . $member;
			}
        	$player->sendMessage(TextFormat::RED . " Leader: " . TextFormat::WHITE . $leader);
        	$player->sendMessage(TextFormat::RED . " Members: " . implode(TextFormat::GRAY . ", ", $members));
        	$player->sendMessage(TextFormat::RED . " Allies: " . TextFormat::WHITE . implode(", ", $faction->getAllies()));
        	$player->sendMessage(TextFormat::RED . " Power: " . TextFormat::WHITE . $faction->getStrength() . " STR");
        	$player->sendMessage(TextFormat::RED . " Balance: " . TextFormat::WHITE . "$" . $faction->getBalance());
        }
    }
}
