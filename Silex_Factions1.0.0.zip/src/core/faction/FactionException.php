<?php

declare(strict_types = 1);

namespace core\faction;

use Exception;

class FactionException extends Exception {

}