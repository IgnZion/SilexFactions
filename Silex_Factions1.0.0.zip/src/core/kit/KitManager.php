<?php

declare(strict_types = 1);

namespace core\kit;

use core\kit\types\ConfigKit;
use core\kit\types\StarterKit;
use core\kit\types\OnceKit;
use core\kit\types\ErebusKit;
use core\kit\types\PheonixKit;
use core\kit\types\ArcaneKit;
use core\kit\types\ErosKit;
use core\kit\types\AvatarKit;
use core\kit\types\JanusKit;
use core\kit\types\MidasKit;
use core\kit\types\AphroditeKit;
use core\kit\types\IrisKit;
use core\kit\types\TartarusKit;
use core\kit\types\ArcherKit;
use core\kit\types\ChaosKit;
use core\kit\types\VaporousKit;
use core\kit\types\MinerKit;
use core\kit\types\ReaperKit;
use core\kit\types\SaintKit;
use core\Elemental;

class KitManager {

    /** @var Elemental */
	private $core;
	/** @var Kit[] */
	private $kits = [];
	/** @var Kit[] */
	private $sacredKits = [];
	/** @var array */
	private $data = [];

    /**
     * KitManager constructor.
     *
     * @param Elemental $core
     *
     * @throws KitException
     */
	public function __construct(Elemental $core) {
		$this->core = $core;
        if(file_exists($this->getCooldownPath() . DIRECTORY_SEPARATOR . "cooldown.json")){
            $this->data = json_decode(file_get_contents($this->getCooldownPath() . DIRECTORY_SEPARATOR . "cooldown.json"), true);
        }
		$this->init();
	}

    /**
     * @throws KitException
     */
	public function init(): void {
		$this->addKit(new StarterKit());
        $this->addKit(new OnceKit());
	    $this->addKit(new AvatarKit());
        $this->addKit(new JanusKit());
    	$this->addKit(new IrisKit());
	    $this->addKit(new MidasKit());
	    $this->addKit(new AphroditeKit());
        $this->addKit(new ErebusKit());
        $this->addKit(new PheonixKit());
        $this->addKit(new ArcaneKit());
        $this->addKit(new ErosKit());
        $this->addKit(new TartarusKit());
        $this->addKit(new VaporousKit());
        $this->addKit(new ChaosKit());
	}

    /**
     * @param string $kit
     *
     * @return Kit|null
     */
	public function getKitByName(string $kit) : ?Kit {
		return $this->kits[$kit] ?? null;
	}

    /**
     * @return Kit[]
     */
	public function getKits(): array {
	    return $this->kits;
    }

    /**
     * @return Kit[]
     */
    public function getSacredKits(): array {
        return $this->sacredKits;
    }

	/**
	 * @param Kit $kit
	 *
	 * @throws KitException
	 */
	public function addKit(Kit $kit) : void {
		if(isset($this->kits[$kit->getName()])) {
			throw new KitException("Attempted to override a kit with the name of \"{$kit->getName()}\" and a class of \"" . get_class($kit) . "\".");
		}
		$this->kits[$kit->getName()] = $kit;
		if($kit->getRarity() > Kit::UNCOMMON) {
		    $this->sacredKits[] = $kit;
        }
	}

    /**
     * @param string $kit
     * @param string $player
     * @return int
     */
	public function getCooldown(string $kit, string $player): int{
	    return isset($this->data[$kit][$player]) ? $this->data[$kit][$player] : 0;
    }

    /**
     * @param string $kit
     * @param string $player
     * @param int $time
     */
    public function addToCooldown(string $kit, string $player, int $time): void{
        $this->data[$kit][$player] = time();
        $this->save();
    }

    /**
     * @param string $kit
     * @param string $player
     */
    public function removeFromCooldown(string $kit, string $player): void{
	    if(isset($this->data[$kit][$player]))
        unset($this->data[$kit][$player]);
    }

    /**
     * @return string
     */
     public function getCooldownPath(): string{
		    return $this->core->getInstance()->getDataFolder() . "kits";

    }
 
	
    public function save(): void{
        file_put_contents($this->getCooldownPath() . DIRECTORY_SEPARATOR . "cooldown.json", json_encode($this->data, JSON_PRETTY_PRINT));
    }
}
