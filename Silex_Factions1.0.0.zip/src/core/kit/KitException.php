<?php

namespace core\kit;

use Exception;

class KitException extends Exception {

}