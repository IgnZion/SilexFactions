<?php

declare(strict_types = 1);

namespace core\watchdog;

use core\Elemental;

class WatchdogManager {

    /** @var Elemental */
    private $core;

    /**
     * WatchdogManager constructor.
     *
     * @param Elemental $core
     */
    public function __construct(Elemental $core) {
        $this->core = $core;
        $core->getServer()->getPluginManager()->registerEvents(new WatchdogListener($core), $core);
    }
}
